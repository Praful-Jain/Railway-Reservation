package reservation;

public class TrainMain {
	public static void main(String[] args) {
		//Calling static function service() using TrainServices class name.
		TrainServices.services();
	}
}
